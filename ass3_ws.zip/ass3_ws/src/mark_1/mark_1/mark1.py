#! /usr/bin/env python3
# Copyright 2021 Samsung Research America
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from geometry_msgs.msg import PoseWithCovarianceStamped
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
import rclpy
from rclpy.duration import Duration
from rclpy.node import Node

"""
Basic navigation demo to go to pose.
"""

#
class MARKCommanderInitiate(Node):
    def __init__(self):
        super().__init__('Listening_Commander')
        self.subscription = self.create_subscription(PoseWithCovarianceStamped, 'pose', self.mark_callback, 10)
        self.subscription #Prevent unused warning
        self.startPose = PoseStamped()
    
    def mark_callback(self, msg):
        #...
        startPose.pose.pose.position.x = msg.pose.pose.position.x
        startPose.pose.pose.position.y = msg.pose.pose.position.y
        startPose.pose.pose.position.z = msg.pose.pose.position.z
        startPose.pose.pose.orientation.z = msg.pose.pose.orientation.z
        startPose.pose.pose.orientation.w = msg.pose.pose.orientation.w
    

    def mark_return_initial_pose(self):
        self.startPose.header.frame_id = 'map'
        #shuts down this node subscription
        self.destroy_subscription(self.subscription)
        return self.startPose

def main():
    rclpy.init()

    navigator = BasicNavigator()
    navigator.node_name = "SimpleCommander"
    firstCommand = MARKCommanderInitiate()
    n = 0
    while(n < 2):
        n = n + 1
    #return PoseStamped() object containing all details
    initial_pose = firstCommand.mark_return_initial_pose()

    initial_pose.header.stamp = navigator.get_clock().now().to_msg()

    navigator.setInitialPose(initial_pose)

    # Go to our demos first goal pose
    goal_pose = PoseStamped()
    goal_pose.header.frame_id = 'map'
    goal_pose.header.stamp = navigator.get_clock().now().to_msg()
    goal_pose.pose.position.x =  initial_pose.pose.position.x 
    goal_pose.pose.position.y =  initial_pose.pose.position.y + 3.0
    goal_pose.pose.orientation.w =  1.0

    # sanity check a valid path exists
    path = navigator.getPath(initial_pose, goal_pose)
    if(path != None):
        print("Path exist!")
       
    else:
        print("Path does not exist!")
        #skip execution
        return

    navigator.goToPose(goal_pose)

    i = 0
    while not navigator.isTaskComplete():
        ################################################
        #
        # Implement some code here for your application!
        #
        ################################################

        # Do something with the feedback
        i = i + 1
        feedback = navigator.getFeedback()
        if feedback and i % 5 == 0:
            print('Estimated time of arrival: ' + '{0:.0f}'.format(
                  Duration.from_msg(feedback.estimated_time_remaining).nanoseconds / 1e9)
                  + ' seconds.')


    # # Do something depending on the return code
    result = navigator.getResult()
    if result == TaskResult.SUCCEEDED:
        print('Goal succeeded!')
    elif result == TaskResult.CANCELED:
        print('Goal was canceled!')
    elif result == TaskResult.FAILED:
        print('Goal failed!')
    else:
        print('Goal has an invalid return status!')


if __name__ == '__main__':
    main()